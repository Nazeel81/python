# Bird-Species-Classification
The project uses a neural-net in tensorflow to classify the species to which a bird belongs to based on the features it has..<br>
There are total 312 features and 11787 examples..<br>
The dataset is avaliable at 
[Caltech-UCSD Birds-200-2011 dataset.](http://www.vision.caltech.edu/visipedia-data/CUB-200-2011/)

