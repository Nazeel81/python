# MinimumFistDetection
This video uses the MediaPipe library to detects hand landmarks and then uses those landmarks to identify a fist. You can watch the whole YouTube video here:
