# Face

This repository is created for the Face_(Detection, Recognition, and ...) tutorial.

You can find the videos of the repo in the following youtube channel:

https://www.youtube.com/watch?v=UhWMC5rSYmA&list=PL2g_5adpoaeKqqgYek-Ql0VKJ-ry46mIq

I'm Pooya Mohammadi and you can contact me from one of the following ways:

LinkedIn: https://linkedin.com/in/pooya-mohammadi

email: pooyamohammadikazaj@gmail.com
