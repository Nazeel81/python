# Facenet with keras
1. tensorflow==1.15.0
2. keras==2.3
3. mtcnn
4. h5py==2.10.0
