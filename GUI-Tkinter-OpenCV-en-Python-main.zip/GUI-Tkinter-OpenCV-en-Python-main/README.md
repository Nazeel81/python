# GUI-Tkinter-OpenCV-en-Python
Hola chicos en este repositorio encontraran toda la programacion para ejecutar sus propios algoritmos de vision artificial en el GUI de Tkinter

### Explicacion:
- En el archivo GUI-AV.py encontraras el codigo general que debes implementar en Python con el fin de que puedas ejecutar tu propia GUI de Tkinter, en este [Video](https://youtu.be/lBGViBaEuS0) te explico toda la programacion.

- Recuerda que debes descargar las imagenes compartidas en este Git con el fin de que no obtengas errores, lo anterior tambien te lo explico desde cero en este [Video](https://youtu.be/lBGViBaEuS0).

- Todos los requerimientos aprenderas a intalarlos en este [Video](https://youtu.be/lBGViBaEuS0), tambien puedes isntalarlos con el archivo requirements.txt. Recuerda que fue ejecutado con Python 3.7.


![Mini (1)](https://user-images.githubusercontent.com/85022752/187078704-72baa601-8570-47e1-86ae-dd656b32e7bb.jpg)


# Recuerda que puedes contribuir a que siga desarrollando:
Simplemente suscribiendote a mi canal de YouTube:
- [Canal YouTube](https://www.youtube.com/channel/UCzwHEOCbsZLjfELperJ6VeQ/videos)

### Siguiendome en mis redes sociales: 
- [Instagram](https://www.instagram.com/santiagsanchezr/)
- [Twitter](https://twitter.com/SantiagSanchezR)
