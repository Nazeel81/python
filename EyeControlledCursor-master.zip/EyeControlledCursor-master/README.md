# Eye Controlled Cursor

![image](https://qph.fs.quoracdn.net/main-qimg-6b00332b630cd176c09da1069a7d4334) <br />
Calibration pending...
